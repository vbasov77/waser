<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class MoreObj extends Model
{
    protected $table = 'more_obj';
    public $timestamps = false;
}
