<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SetWash extends Model
{
    protected $table = 'set_wash';
    public $timestamps = false;
}
