

jQuery('#datetimepicker').datetimepicker({

    datepicker:false,
    format:'H:i',


});
