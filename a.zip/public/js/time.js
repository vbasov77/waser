var al1 = array;
jQuery('#datetimepicker').datetimepicker({
    datepicker: false,
    format: 'H:i',
    inline: true,
    allowTimes: al1,

});

