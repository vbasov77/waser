<?php $__env->startSection('content'); ?>
    <script>
        var datedis = <?php echo json_encode('02.11.2022', 15, 512) ?>;
    </script>
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h3>Выберете дату</h3>
                    <form action="/get_date" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="obj_id" value="<?php echo e($id); ?>">
                        <div>
                            <input type="text" id="timepicker" name="date" class="form-control" required
                                   autocomplete="off">
                        </div>
                        <div class="float-center">
                            <input class="btn btn-outline-primary" type="submit" value="Продолжить">
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/calendars/cal.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views/orders/orders_cal.blade.php ENDPATH**/ ?>