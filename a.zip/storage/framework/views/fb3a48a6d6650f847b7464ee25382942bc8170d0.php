<?php $__env->startSection('content'); ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <h3>Забронированное время</h3>
                    <?php if(!empty($data)): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card text-center">
                                <div class="card-header">
                                    Номер заказа: <?php echo e($dat['id']); ?><br>
                                    <?php echo e($num); ?>

                                </div>
                                <div class="card-body">
                                    <h4><?php echo e($dat ['time_wash']); ?></h4>
                                    <?php echo e($dat['date_book']); ?>

                                    <h5><?php echo e($dat['total_cost']); ?> руб</h5> <br>
                                </div>

                                <div class="card-footer text-muted">
                                    Тип авто: <?php echo e($dat ['type_auto']); ?><br>
                                    Тип мойки: <?php echo e($dat ['type_wash']); ?><br>

                                    <a onClick="return confirm('Подтвердите удаление!')"
                                       href='/order/<?php echo e($dat['id']); ?>/delete' type='button'
                                       class='btn btn-outline-danger btn-sm'>Удалить</a>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php else: ?>
                <br> Заказов не найдено
        <?php endif; ?>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views/orders/my_orders.blade.php ENDPATH**/ ?>