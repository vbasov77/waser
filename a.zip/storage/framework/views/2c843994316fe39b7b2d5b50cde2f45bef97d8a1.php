<?php $__env->startSection('content'); ?>
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <form action="/admin_book" method="post">
                        <?php echo csrf_field(); ?>
                        <input style="float: left" name="obj_id" type="hidden" value="<?php echo e($obj_id); ?>">
                        <br>
                        <h3>Запись на мойку (админ)</h3><br>
                        <div>
                            <label for="timepicker[]">C<b style="color: red">*</b></label>
                            <input type="text" id="date_timepicker_start" autocomplete="off" name="timepicker[]"
                                  placeholder="Выберете время" class="form-control" required><br>
                        </div>

                        <div>
                            <label for="timepicker[]">До<b style="color: red">*</b></label>
                            <input type="text" id="date_timepicker_end" autocomplete="off" name="timepicker[]"
                                   placeholder="Выберете время"  class="form-control" required>
                        </div>
                        <br>


                                <div class="floatleft">
                                    <?php $i = 0
                                    ?>
                                    <h5>Тип авто</h5>
                                    <?php $__currentLoopData = $auto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" class="custom-control-input" id="initial<?php echo e($i); ?>"
                                                   name="class_auto"
                                                   value="<?php echo e($item); ?>"/>
                                            <label for="initial<?php echo e($i); ?>" class="custom-control-label"><?php echo e($item); ?></label><br>
                                        </div>
                                        <?php $i++
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <br>
                                    <?php $l = 0
                                    ?>
                                    <h5>Тип мойки</h5>
                                    <?php $__currentLoopData = $wash; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" name="class_wash" class="custom-control-input"
                                                   id="ini<?php echo e($l); ?>"
                                                   value="<?php echo e($val); ?>"/>
                                            <label for="ini<?php echo e($l); ?>"
                                                   class="custom-control-label"> <?php echo e($val); ?></label><br>
                                        </div>
                                        <?php $l++
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                        <div>
                            <label for="name_user">ФИО</label>
                            <input type="text" autocomplete="off" name="name_user"
                                   placeholder="ФИО"  class="form-control" value="<?php echo e($_POST ['name_user'] ?? ""); ?>" required>
                        </div>
                        <br>
                        <div>
                            <label for="user_email">Email</label>
                            <input type="email" autocomplete="off" name="user_email"
                                   placeholder="Email"  class="form-control" value="<?php echo e($_POST ['user_email'] ?? ""); ?>" required>
                        </div>
                        <br>
                        <div>
                            <label for="phone_user">Телефон</label>
                            <input  autocomplete="off" name="phone_user"
                                   placeholder="Телефон"  class="form-control tel" value="<?php echo e($_POST ['phone_user'] ?? ""); ?>" required>
                        </div>
                        <br>

                        <div>
                            <label for="total_cost">Сумма</label>
                            <input type="number" autocomplete="off" name="total_cost"
                                   placeholder="Сумма"  class="form-control" value="<?php echo e($_POST ['total_cost'] ?? ""); ?>" required>
                        </div>
                        <br>
                        <b style="color: red">* - <small>обязательно для заполнения</small></b>
                        <br>
                        <input class="btn btn-outline-primary" type="submit" value="Продолжить">
                    </form>
                </div>
            </div>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script>
            var array = <?php echo json_encode($work_time, 15, 512) ?>;
        </script>
        <script src="<?php echo e(asset('js/calendars/time_admin.js')); ?>" defer></script>
        <script src="<?php echo e(asset('js/mask.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views//admin_book/add.blade.php ENDPATH**/ ?>