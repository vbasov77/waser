<?php $__env->startSection('content'); ?>
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="gx-4 gx-lg-5 justify-content-center">

                <h3 style="margin-top: 40px">Объекты</h3><br>
                <?php if(!empty($objects)): ?>
                    <?php for($i = 0; $i < count($objects); $i++): ?>
                        <div class="card text-center" style="margin: 15px">
                            <div class="card-header">
                                <?php echo e($objects[$i]['name_obj']); ?>

                            </div>
                            <div class="card-body">
                                <button class="btn btn-success btn-sm" style="color: white; "
                                        onclick="window.location.href = 'object/<?php echo e($objects[$i]['id']); ?>/today';">
                                    Сегодня
                                </button>
                                <button class="btn btn-primary btn-sm" style="color: white; "
                                        onclick="window.location.href = 'object/<?php echo e($objects[$i]['id']); ?>/cal';">
                                    Календарь
                                </button>
                            </div>
                        </div>
                    <?php endfor; ?>
                <?php else: ?>
                    <br>
                    Объектов не найдено
                <?php endif; ?>
            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views/objects/my_objects.blade.php ENDPATH**/ ?>