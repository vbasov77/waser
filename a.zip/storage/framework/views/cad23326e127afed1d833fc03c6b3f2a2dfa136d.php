<?php $__env->startSection('content'); ?>

    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="gx-4 gx-lg-5 justify-content-center">
                <h1><?php echo e($date); ?></h1>
                <?php if(!empty($obj_id)): ?>
                    <div class="card-footer text-muted" style="margin: 5px">
                        <button class="btn btn-success" style="color: white; "
                                onclick="window.location.href = '/admin_book/obj_id<?php echo e($obj_id); ?>';">
                            Добавить заказ
                        </button>
                    </div>
                <?php endif; ?>
                <h3 style="margin-top: 40px">Забронированное время</h3><br>
                <?php if(!empty($data)): ?>
                    <?php for($i = 0; $i < count($data); $i++): ?>
                        <?php
                        $phone = preg_replace("/[^0-9]/", '', $data [$i][0] ['phone_user']);
                        $auto = \Illuminate\Support\Facades\DB::table('profile')->where('phone_user', $data [$i][0] ['phone_user'])->value('auto_user');

                        ?>
                        <div class="card text-center" style="margin: 15px">
                            <div class="card-header">
                                Номер заказа: <?php echo e($data [$i][0] ['id']); ?><br>
                                <?php echo e($data[$i][0] ['date_book']); ?>

                                <h3><?php echo e($data [$i][0] ['time_wash']); ?></h3><br>
                            </div>
                            <div class="card-body">
                                <h5><?php echo e($data [$i][0] ['total_cost']); ?> руб</h5><br>
                                Тип авто: <?= $data [$i][0] ['type_auto'] ?><br>
                                Тип мойки: <?= $data [$i][0] ['type_wash'] ?><br>
                                <a href='tel:+<?php echo e($phone); ?>'> <?php echo e($data [$i][0]['phone_user']); ?></a>
                                <?php echo e($data [$i][0] ['name_user']); ?><br>
                                <b><?= $auto ?></b><br>


                                <?php if(!empty($data [$i][0]['more_book'])): ?>
                                    <b>Дополнительно:</b><br>
                                    <?php
                                    $more_book = explode(";", $data [$i][0]['more_book'])
                                    ?>
                                    <?php $__currentLoopData = $more_book; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        $more = explode(',', $book);
                                        ?>
                                        <?php echo e($more[2] . " " . $more [3] . " руб " . $more [4] . " мин"); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </div>

                            <div class="card-footer text-muted">

                                <button class="btn btn-success btn-sm" style="color: white; "
                                        onclick="window.location.href = '#';">
                                    Редактировать
                                </button>

                                <a onClick="return confirm('Подтвердите удаление!')"
                                   class="btn btn-danger btn-sm" style="color: white; "
                                   href='/delete/<?= $data[$i][0]['id'] . ';' . $date . ';' . $data[$i][0]['obj_id'] ?>/order'>
                                    Удалить
                                </a>

                                <form action="/in_archive" method="post">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="id" value="<?php echo e($data[$i][0]['id']); ?>"/>
                                    <input type="hidden" name="obj_id" value="<?php echo e($data[$i][0]['obj_id']); ?>"/>
                                    <i>Отзыв администратора</i><br>
                                    <input type="text" name="comment_admin" id="otz" class="form-control"
                                           placeholder="Отзыв администратора"/>
                                    <br>
                                    <div>
                                        <input id="submit" class="btn btn-outline-dark btn-sm" type="submit"
                                               value="В архив"/>
                                    </div>
                                </form>

                            </div>
                        </div>
                    <?php endfor; ?>
                <?php else: ?>
                    <br>
                    Заказов не найдено
                <?php endif; ?>
            </div>
        </div>
    </section>
    <?php $__env->startPush('scripts'); ?>
        <script src="<?php echo e(asset('js/otz.js')); ?>" defer></script>
    <?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views/orders/orders.blade.php ENDPATH**/ ?>