<?php $__env->startSection('content'); ?>
    <style>
        .col-1-2 {
            width: 50%;
            text-align: -webkit-center;
        }

        .floatleft {
            width: 100%;
            margin-top: 50px;
            float: left;
            text-align: left;
            font-size: 20px;
        }

        .float-center {
            margin-top: 30px;
            margin-bottom: 60px;
            text-align: center;
        }

        .xdsoft_timepicker.active {
            display: block;
            width: 350px;
        }

        .air-datepicker.-inline- {
            width: 100%;
        }

        input#el {

            margin-bottom: 15px;
        }

        .text-calendar {
            font-size: 20px;
        }

        .border_none {
            display: none;
        }
    </style>
    <script>
        var datedis = <?php echo json_encode($datedis, 15, 512) ?>;
    </script>
    <section class="about-section text-center" id="about">
        <div class="container px-4 px-lg-5">
            <div class="row gx-4 gx-lg-5 justify-content-center">
                <div class="col-lg-8">
                    <?php if(!empty($message)): ?>
                        <div style="background-color: red; color:#ffffff; padding: 5px;margin: 15px">
                            <center> <?php echo e($message); ?></center>
                        </div>
                    <?php endif; ?>
                    <form action="/get_time" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="obj_id" value="<?php echo e($obj_id ?? ''); ?>">
                        <div class="text-calendar">
                            <b>Тип авто:</b> <?php echo e($car); ?><br><br>
                        </div>

                        <h3> Выберете дату и тип мойки </h3><br>
                        <div>
                            <input type="text" id="el" name="el" class="form-control" required autocomplete="off">
                        </div>

                        <div class="card" style="margin-top: 40px">
                            <div class="card-body">
                                <div class="floatleft">
                                    <h3>Выберете тип мойки</h3>
                                    <?php $i = 0
                                    ?>
                                    <?php $__currentLoopData = $wash; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                        foreach ($costWashArr as $item) {
                                            $costArr = explode('&', $item);
                                            $typeWash = $car . ":" . $val;
                                            if ($typeWash === $costArr [0]) {
                                                $result = explode('/', $costArr[1]);
                                                $cost = $result[0];
                                                $timeWash = $result[1];
                                                break;
                                            }
                                        }
                                        ?>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" name="class_wash" class="custom-control-input"
                                                   id="ini<?php echo e($i); ?>"
                                                   value="<?php echo e($val); ?>" required/>
                                            <label for="ini<?php echo e($i); ?>"
                                                   class="custom-control-label"> <?php echo e($val . ': ' . $cost . 'руб '); ?>

                                                <small><?php echo e($timeWash . 'мин'); ?></small></label><br>
                                        </div>
                                        <?php $i++
                                        ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </div>
                            </div>
                        </div>
                        <?php if(!empty($more_obj)): ?>
                            <div class="card">
                                <div class="card-body">
                                    <div class="floatleft">
                                        <h3>Выберете дополнительную услугу</h3>
                                        <?php $__currentLoopData = $more_obj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $obj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="checkbox"
                                                   name="more_obj[]"
                                                   value="<?php echo e($obj['id'] . "," . $obj['obj_id'] . "," . $obj['name_more'] . "," . $obj['cost_more'] . "," . $obj['time_more']); ?>">
                                            <label for="more_obj[]"><?php echo e($obj['name_more'] . " " . $obj['cost_more'] . "руб "); ?>

                                                <small><?php echo e(" +" . $obj['time_more'] . "мин"); ?></small></label>


                                            <br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>

                        <?php endif; ?>
                        <div class="border_none">
                            <label for="class_auto"><b>Тип авто:</b></label>
                            <input value="<?= $_POST['class_auto'] ?>" readonly="readonly" type="text"
                                   name="class_auto"
                                   method="post"><br>
                        </div>
                        <div class="float-center">
                            <input class="btn btn-outline-primary" type="submit" value="Продолжить">
                        </div>


                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views/set.blade.php ENDPATH**/ ?>