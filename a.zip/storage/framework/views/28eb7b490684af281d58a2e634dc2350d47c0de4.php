
Здравствуйте!<br>
<br>
<br>
<h3>Новая запись нам мойку авто</h3><br>
<?php echo e($send_mail ['address']); ?><br>
<br>
Дата: <?php echo e($send_mail ['date_book']); ?> <br>
Время: <?php echo e($send_mail ['time_wash']); ?><br>
<br>
Итого: <?php echo e($send_mail ['total_cost']); ?> руб<br>
<br>
<br>
С уважением,<br>
администрация сайта <?php echo e(config('app.name')); ?>!<?php /**PATH C:\OpenServer\domains\washer3.loc\resources\views/mail/send_book_admin.blade.php ENDPATH**/ ?>