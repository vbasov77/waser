
Здравствуйте!<br>
<br>
<br>
<h3>Новая запись нам мойку авто</h3><br>
{{$send_mail ['address']}}<br>
<br>
Дата: {{$send_mail ['date_book']}} <br>
Время: {{ $send_mail ['time_wash']}}<br>
<br>
Итого: {{$send_mail ['total_cost']}} руб<br>
<br>
<br>
С уважением,<br>
администрация сайта {{config('app.name')}}!