# Booking a car wash time.

At the moment, this is my last application on Laravel, which is still in development.

The application is already ready and is used by users, for their part - daily maintenance of the site, analysis, improvement of functionality.

Rather, this is my most complex application, which implements more capacious logic, flexible application settings from the admin panel and extensive functionality.

Also, as on some previous sites, ready-made calendar solutions in Javascript are implanted.
