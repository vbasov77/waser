

jQuery('#datetimepicker2').datetimepicker({

    datepicker:false,
    format:'H:i',


});
