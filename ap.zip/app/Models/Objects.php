<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Objects extends Model
{
    protected $table = 'objects';
    public $timestamps = false;

}
