<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TypeWash extends Model
{
    protected $table = 'type_wash';
    public $timestamps = false;

}
