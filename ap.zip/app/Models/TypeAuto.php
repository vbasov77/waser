<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TypeAuto extends Model
{
    protected $table = 'type_auto';
    public $timestamps = false;
}
